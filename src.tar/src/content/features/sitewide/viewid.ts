import { callRobloxApi, callRobloxApiJson } from '../../core/api.js';
import {
    getPlaceIdFromUrl,
    getAssetIdFromUrl,
    getUserIdFromUrl,
} from '../../core/idExtractor.js';
import { t } from '../../core/locale/i18n.js';
import { createOverlay } from '../../core/ui/overlay.js';
import { parseMarkdown } from '../../core/utils/markdown.js';

type RequestType = {
    action: 'view-ids',
    data: {
        targetId: string | number
    }
};

export function init() {
    chrome.runtime.onMessage.addListener(async (request: any | RequestType) => {
        if (request.action === 'view-ids' && request.data?.id) {
            request = request as RequestType;
            const id = Number(request.data.targetId);

            const bundledata = (await callRobloxApiJson({
                subdomain: 'catalog',
                endpoint: `https://catalog.roblox.com/v1/bundles/details?bundleIds=${id}`
            }))?.[0];

            const itemType: number = (!!bundledata) ? 2 : 1;

            const itemdata = (await callRobloxApiJson({
                subdomain: 'catalog',
                endpoint: 'https://catalog.roblox.com/v1/catalog/items/details',
                method: 'POST',
                body: {
                  "items": [
                    {
                      "itemType": itemType,
                      "id": id
                    }
                  ]
                }
            }))?.["data"]?.[0];

            if (itemdata === undefined)
                console.error(`RoValra: Failed to retrieve item data for ${itemType === 1 ? "Asset" : "Bundle"} ${id}.`);

            console.log(itemdata);
        }
    });

    document.addEventListener(
        'mousedown',
        async (e) => {
            if (e.button !== 2) return;

            const link = e.target?.closest('a');
            const ids = [];
            const translation = await t("copyId.viewId");

            if (link) {
                const url = link.href;

                const bundleMatch = url.match(/\/bundles\/(\d+)/);
                const catalogMatch = url.match(/\/catalog\/(\d+)/);
                const gamePassMatch = url.match(/\/game-pass\/(\d+)/);
                const badgeMatch = url.match(/\/badges\/(\d+)/);
                const groupMatch = url.match(/\/(?:groups|communities)\/(\d+)/);
                const eventMatch = url.match(/\/events\/(\d+)/);
                const devProductMatch = url.match(
                    /\/developer-product\/\d+\/product\/(\d+)/,
                );

                let targetId;

                if (bundleMatch) {
                    ids.push(bundleMatch[1]);
                } else if (catalogMatch) {
                    ids.push(catalogMatch[1]);
                } else if (gamePassMatch) {
                    ids.push(gamePassMatch[1]);
                } else if (badgeMatch) {
                    ids.push(badgeMatch[1]);
                } else if (groupMatch) {
                    ids.push(groupMatch[1]);
                } else if (eventMatch) {
                    ids.push(eventMatch[1]);
                } else if (devProductMatch) {
                    ids.push(devProductMatch[1]);
                } else {
                    const assetId = getAssetIdFromUrl(url);
                    if (assetId)
                        ids.push(assetId);
                }
            }

            chrome.runtime.sendMessage({
                action: 'updateContextMenu',
                feature: 'viewid',
                ids: ids,
                data: {
                    title: translation
                }
            });
        },
        { capture: true },
    );
}
